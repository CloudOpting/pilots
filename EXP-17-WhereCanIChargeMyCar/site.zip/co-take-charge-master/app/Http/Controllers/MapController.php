<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Storage;

class MapController extends Controller
{
    /**
     * Show the map.
     *
     * @return Response
     */
    public function showMap()
    {
        $data = Storage::get('charging_poles.json');
        $data2 = Storage::get('tour.json');
        $pois = Storage::get('cbis.xml');

        //ConvertXMLtoGEOJSON($pois);

        //return view('map', ['data' => $data, 'data2' => $data2, 'pois' => ConvertXMLtoGEOJSON($pois)]);



        $your_xml_response = $pois;
        $clean_xml = str_ireplace(['s:', 'a:', 'b:', 'i:'], '', $your_xml_response);
        
        $xml=simplexml_load_string($clean_xml) or die("Error: Cannot create object");

        $geojson = array( 'type' => 'FeatureCollection', 'features' => array());

        foreach( $xml->children()->children()->children()->children() as $node ) {
            /*echo( $node->Id[0]->Id .' ' );
            echo( $node->SystemName. '<br />' );
            echo( '<img src="'.$node->Media[0]->MediaType[0]->Url.'" />' );
            echo( $node->Location[0]->Latitude. ' ' );
            echo( $node->Location[0]->Longitude. '<br />' );

            echo('<br />');*/

            if($node->Location[0]->Latitude != 0 || $node->Location[0]->Latitude > 0 || $node->Location[0]->Latitude != false) {

                $marker = array(
                    'type' => 'Feature',
                    'features' => array(
                        'type' => 'Feature',
                        'properties' => array(
                            'id' => "".$node->Id[0]->Id."",
                            'name' => "".$node->SystemName."",
                            'marker-color' => '#f00',
                            'marker-size' => 'small',
                            //'img' => $node->Media[0]->MediaType[0]->Url
                            //'url' => 
                            ),
                        "geometry" => array(
                            'type' => 'Point',
                            'coordinates' => array( 
                                        (float)$node->Location[0]->Longitude,
                                        (float)$node->Location[0]->Latitude
                                        
                            )
                            
                        )
                    )
                );

                //print_r($node->Location[0]->Latitude. ', '.$node->Location[0]->Latitude.'<br />');

                array_push($geojson['features'], $marker['features']);
            } 
        }
        return view('map', ['data' => $data, 'data2' => $data2, 'pois' => json_encode($geojson)]);
    }

    public function ConvertXMLtoGEOJSON($pois)
    {
        $your_xml_response = $pois;
        $clean_xml = str_ireplace(['s:', 'a:', 'b:', 'i:'], '', $your_xml_response);
        
        $xml=simplexml_load_string($clean_xml) or die("Error: Cannot create object");

        $geojson = array( 'type' => 'FeatureCollection', 'features' => array());

        foreach( $xml->children()->children()->children()->children() as $node ) {
            /*echo( $node->Id[0]->Id .' ' );
            echo( $node->SystemName. '<br />' );
            echo( '<img src="'.$node->Media[0]->MediaType[0]->Url.'" />' );
            echo( $node->Location[0]->Latitude. ' ' );
            echo( $node->Location[0]->Longitude. '<br />' );

            echo('<br />');*/

            if($node->Location[0]->Latitude != 0 || $node->Location[0]->Latitude > 0 || $node->Location[0]->Latitude != false) {

                $marker = array(
                    'type' => 'Feature',
                    'features' => array(
                        'type' => 'Feature',
                        'properties' => array(
                            'id' => "".$node->Id[0]->Id."",
                            'name' => "".$node->SystemName."",
                            'marker-color' => '#f00',
                            'marker-size' => 'small',
                            //'img' => $node->Media[0]->MediaType[0]->Url
                            //'url' => 
                            ),
                        "geometry" => array(
                            'type' => 'Point',
                            'coordinates' => array( 
                                        (float)$node->Location[0]->Longitude,
                                        (float)$node->Location[0]->Latitude
                                        
                            )
                            
                        )
                    )
                );

                //print_r($node->Location[0]->Latitude. ', '.$node->Location[0]->Latitude.'<br />');

                array_push($geojson['features'], $marker['features']);
            } 
        }
        //return view('map', ['data' => $data, 'data2' => $data2, 'pois' => json_encode($geojson)]);
        return json_encode($geojson);
    }
}