<!DOCTYPE html>
<html>
    <head>
        <title>Co-Take-Charge</title>

        <link href="https://fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="http://cdn.leafletjs.com/leaflet/v0.7.7/leaflet.css" />
        <link rel="stylesheet" href="routing/leaflet-routing-machine.css" />
        <link rel="stylesheet" href="routing/leaflet.awesome-markers.css">
        <link rel="stylesheet" href="routing/font-awesome.min.css">
        <link rel="stylesheet" href="routing/bootstrap-slider.css">
        <script src="http://cdn.leafletjs.com/leaflet/v0.7.7/leaflet.js"></script>
        <script src="routing/leaflet-routing-machine.js"></script>
        <script src="routing/leaflet.awesome-markers.js"></script>
        <script src="routing/bootstrap-slider.js"></script>

        <style>
            html, body {
                height: 100%;
            }

            body {
                margin: 0;
                padding: 0;
                width: 100%;
                display: table;
                font-weight: 100;
                font-family: 'Lato';
            }

            .container {
                text-align: center;
                display: table-cell;
                vertical-align: middle;
            }

            .content {
                text-align: center;
                display: inline-block;
            }

            .title {
                font-size: 96px;
            }
            #map { 
                width: 100%;
                height: 480px; 
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div id="map"></div>
            <div class="content">
                
            </div>
            <div>
                <span id="rangeOfCarValLabel" style="font-family: arial">Range of your car: <span id="rangeOfCarVal" style="font-weight: bold">200</span> km</span>
            </div>
            <div>
                <!-- <input id="rangeOfCar_Id"> Range of car (km) </input> 
                <input type="text" id="slider1" class="span2 slider" value="80" data-slider-min="50" data-slider-max="90" data-slider-step="0.1" data-slider-value="83"  data-slider-selection="after" data-slider-tooltip="hide">
                <script> </script> -->
                <span style="font-family: arial">10 km</span>
                <input id="rangeOfCar_Id" data-slider-id='slider_id' type="text"/> <!-- This is the slider -->
                <span style="font-family: arial">1000 km</span>
             </div>
             <div>
                <button id="routeButton_Id" onclick="RouteToPoint(destinationMarker.getLatLng())"> Route to marker </button>
             </div>
             <div>
                <button id="chargepoleButton_Id" onclick="ShowAllChargepoles()"> Show all chargepoles</button>
                <button id="poiButton_Id" onclick="ShowAllPOI()"> Show all Points of Interest</button>
             </div>
             <div>
                <button id="clearMapButton_Id" onclick="ClearMap()"> Clear Map</button>
                <button id="resetButton_Id" onclick="ResetMap()"> Reset Map</button>
             </div>
        </div>
        <script>
            /*
            * Static values
            */
            var chargepole_geojsonLayer = L.geoJson();           // GeoJSON Layer, all chargepoles
            var tour_geojsonLayer = L.geoJson();                 // GeoJSON Layer, all points of interest
            var tour_points_in_range_geojsonLayer = L.geoJson(); // GeoJSON Layer, all points of interest in range of the selected chargepole
            var userPosition_geojsonLayer = L.geoJson();         // GeoJSON Layer, the  user's position reported from the browser
            var circles_geojsonLayer = L.geoJson();              // GeoJSON Layer, all the circles on the map (circles are walking distance from chargepoles)
            var routeMarkers_geojsonLayer = L.geoJson();         // GeoJSON Layer, all the markers of the waypoints that comes from routing
            var user_position = {latitude:0, longitude:0};       // Object, latitude and longitude for the user's position reported from the browser
            var destinationPopup = L.popup();                    // The popup of the destinationMarker
            var destinationMarker = L.marker();                  // The marker that is created when the user clicks on the map or when a chargepole is selected
            var rangeOfCar = 0;                                  // Meters, Change to take number from textbox "rangeOfCar_Id"
            var rangeOfCarDefault = 200000;                      // Meters, the default range of the car if no range has been given
            var powerSaftyLevel = 0.70;                          // Procentage, Change to take number from textbox 
            var walkingDistance = 1000;                          // Meters, radii of circle around selected chargepoles
            var user_route;                                      // 
            var calculated_route;                                // 
            
            /*
            * Configurables values
            */
            var map = L.map('map', {
                center: [56.505, 12.09], 
                zoom: 6
            });                                                  // The map, setView(<LatLng> center, <Number> zoom)
            var canUserClickOnTheMap = true;                     // Bool, true if user can click on the map to add a marker
            var rangeOfCarDefault = 200000;                      // Meters, the default range of the car if no range has been given
            var powerSaftyLevel = 0.75;                          // Procentage, Change to take number from textbox 
            var walkingDistance = 1000;                          // Meters, radii of circle around selected chargepoles
            
            /* Icons */
            var userLocationIcon = L.AwesomeMarkers.icon({
                icon: 'home',               // http://fortawesome.github.io/Font-Awesome/icons/
                prefix: 'fa',               // default: glyphicon (fa is needed with Font-Awesome)
                markerColor: 'green' //,    // default: blue
                //iconColor: 'white',       // default: white
                //spin: false,              // default: false
                //extraClasses: ''          // default: ''
            });
            var destinationIcon         = L.AwesomeMarkers.icon({ icon: 'flag', prefix: 'fa', markerColor: 'green' });
            var chargepoleIcon          = L.AwesomeMarkers.icon({ icon: 'bolt', prefix: 'fa', markerColor: 'orange' });
            var POIIcon                 = L.AwesomeMarkers.icon({ icon: 'check', prefix: 'fa', markerColor: 'blue' });
            var noChargepoleInRangeIcon = L.AwesomeMarkers.icon({ icon: 'warning', iconColor: 'yellow', prefix: 'fa', markerColor: 'red' });

            /* Text strings */
            var userPosition_text       = "Your current location";
            var destination_text        = "Your destination";
            var chargepoleNotFound_text = "No chargepoles in range. Change battery."

            /*var mySlider = new Slider("input.slider", {
                    id: 'rangeOfCar_Id', 
                    min: 10, 
                    max: 100, 
                    step: 10,
                    orientation: 'horizontal',
                    value: 20, 
                    handle: 'round'
                });*/

            var slider = new Slider('#rangeOfCar_Id', {
                formatter: function(value) {
                    return 'Current value: ' + value;
                }, 
                step: 10, 
                min: 100, 
                max: 1000, 
                value: 200, 
                tooltip: 'hide', 
            });

            slider.on("slide", function(slideEvt) {
                document.getElementById('rangeOfCarVal').innerHTML = slideEvt;
            });

            map.on('routingerror', function() {
                try {
                    map.getCenter();
                } catch (e) {
                    map.fitBounds(L.latLngBounds(waypoints));
                }
                L.Routing.errorControl(control).addTo(map);
            });

            /*
            * Start of main script
            */

            L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
                attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="http://mapbox.com">Mapbox</a>',
                maxZoom: 18,
                id: 'alexxhansson.p3mip1d7',
                accessToken: 'pk.eyJ1IjoiYWxleHhoYW5zc29uIiwiYSI6IjQ4ZmViMDZjMWFiYzFjMDI1MTMxMjE2ZmY3YTc0Yjk0In0.6vIc2u5xiaGSSonYdowcxQ'
            }).addTo(map);

            BuildLayers();

            if (navigator.geolocation) {
               navigator.geolocation.getCurrentPosition(GetLocation);
            }else {
                // Error message, "Can't find your location", Geolocation blocked, turned off or not supported by browser
                user_position.latitude = 0;
                user_position.longitude = 0;
            }

            /*
            * End of main script
            */

            /*
            * Start of functions
            */

            map.on('click', function(e) {
                if(canUserClickOnTheMap) {
                    destinationPopup
                        .setLatLng(e.latlng)
                        .setContent("Latitude: " + e.latlng.lat + "<br>\nLongitude: " + e.latlng.lng);
                    destinationMarker
                        .setLatLng(e.latlng)
                        .setIcon(destinationIcon)
                        .bindPopup(destinationPopup)
                        .addTo(map);
                }
            });

            function CalculateWhenToCharge(routes) {
                var distanceTraveled = 0;
                var newRoutes = [];
                var nrOfChargepoles = chargepole_geojsonLayer.getLayers().length;
                var nearestChargepole = {
                                         coordinates: SwitchLatLong(chargepole_geojsonLayer.getLayers()[0].feature.geometry.coordinates), 
                                         distance: routes.coordinates[0].distanceTo( SwitchLatLong(chargepole_geojsonLayer.getLayers()[0].feature.geometry.coordinates)), 
                                         name: chargepole_geojsonLayer.getLayers()[0].feature.properties.name
                                        };

                // First route
                newRoutes.push(new L.Routing.Waypoint([user_position.latitude, user_position.longitude], userPosition_text));

                // Chargepole routes
                if(routes.coordinates.length > 0) {
                    for(var i = 1; i < routes.coordinates.length; i++) {
                        distanceTraveled += routes.coordinates[i].distanceTo(routes.coordinates[i-1]);

                        if(distanceTraveled >= (rangeOfCar * powerSaftyLevel)) {
                            
                            
                            for(var y = 0; y < nrOfChargepoles; y++) {
                                if(routes.coordinates[i].distanceTo( SwitchLatLong(chargepole_geojsonLayer.getLayers()[y].feature.geometry.coordinates)) < nearestChargepole.distance) {
                                    nearestChargepole.coordinates = SwitchLatLong(chargepole_geojsonLayer.getLayers()[y].feature.geometry.coordinates);
                                    nearestChargepole.distance = routes.coordinates[i].distanceTo( SwitchLatLong(chargepole_geojsonLayer.getLayers()[y].feature.geometry.coordinates));
                                    nearestChargepole.name = chargepole_geojsonLayer.getLayers()[y].feature.properties.name;
                                }
                            }
                            
                            if(powerSaftyLevel >= 1) {
                                newRoutes.push(new L.Routing.Waypoint(routes.coordinates[i], chargepoleNotFound_text));

                                distanceTraveled = 0;
                                powerSaftyLevel = 0.75;
                            }
                            /*
                            * If this happens it means that a new chargepole wasn't found that is nearer the driver than the last one he visited
                            * or there are no chargepoles in range.  
                            */
                            else if(nearestChargepole.name == newRoutes[newRoutes.length-1].name || routes.coordinates[i].distanceTo(nearestChargepole.coordinates) > (rangeOfCar * (1 - powerSaftyLevel))) {
                                powerSaftyLevel = 1;
                            } else {
                                newRoutes.push(new L.Routing.Waypoint(nearestChargepole.coordinates, nearestChargepole.name));

                                nearestChargepole = {
                                         coordinates: SwitchLatLong(chargepole_geojsonLayer.getLayers()[0].feature.geometry.coordinates), 
                                         distance: routes.coordinates[0].distanceTo( SwitchLatLong(chargepole_geojsonLayer.getLayers()[0].feature.geometry.coordinates)), 
                                         name: chargepole_geojsonLayer.getLayers()[0].feature.properties.name
                                        };

                                distanceTraveled = 0;
                                powerSaftyLevel = 0.75;
                            }
                        }
                    }
                }

                // Last route
                newRoutes.push(new L.Routing.Waypoint(destinationMarker.getLatLng(), destination_text));

                if(calculated_route != null) {
                    map.removeControl(calculated_route);
                }
                
                calculated_route = L.Routing.control({
                    waypoints: [],
                    createMarker: function() { return null; },
                    draggableWaypoints: false, 
                    addWaypoints: false
                });

                var marker;
                for(var x = 0; x < newRoutes.length; x++) {
                    calculated_route.spliceWaypoints(x, calculated_route.getWaypoints().length, newRoutes[x]);
                    if(newRoutes[x].name == chargepoleNotFound_text) {
                        marker = L.marker(newRoutes[x].latLng, {icon:noChargepoleInRangeIcon});
                    } else if(newRoutes[x].name == userPosition_text) {
                        marker = L.marker(newRoutes[x].latLng, {icon:userLocationIcon});
                    } else if(newRoutes[x].name == destination_text) {
                        marker = L.marker(newRoutes[x].latLng, {icon:destinationIcon});
                    } else {
                        marker = L.marker(newRoutes[x].latLng, {icon:chargepoleIcon});
                    }
                    //marker = L.marker(newRoutes[x].latLng);
                    marker.bindPopup(newRoutes[x].name);
                    routeMarkers_geojsonLayer.addLayer(marker);
                }

                calculated_route.route();
                calculated_route.addTo(map);
                map.removeLayer(destinationMarker);
                map.removeLayer(userPosition_geojsonLayer);
                map.addLayer(routeMarkers_geojsonLayer);

                FindPOIS(newRoutes);
            }

            function FindPOIS(routes) {
                if(map.hasLayer(circles_geojsonLayer)) {
                    map.removeLayer(circles_geojsonLayer);
                }
                if(map.hasLayer(tour_points_in_range_geojsonLayer)) {
                    map.removeLayer(tour_points_in_range_geojsonLayer);
                }
                circles_geojsonLayer = L.geoJson();
                tour_points_in_range_geojsonLayer = L.geoJson();
                
                for(var i = 1; i < routes.length-1; i++) {
                    PaintCircleAtPoint(routes[i]);

                    for(var y = 0; y < tour_geojsonLayer.getLayers().length; y++) {
                        if(routes[i].latLng.distanceTo(SwitchLatLong(tour_geojsonLayer.getLayers()[y].feature.geometry.coordinates)) < walkingDistance) {
                            tour_points_in_range_geojsonLayer.addLayer(tour_geojsonLayer.getLayers()[y]);
                        }
                    }
                }
                if(tour_points_in_range_geojsonLayer.getLayers().length > 0) {
                    map.addLayer(tour_points_in_range_geojsonLayer);
                }
            }

            function RouteToPoint(destination) {
                if(map.hasLayer(routeMarkers_geojsonLayer)) {
                    map.removeLayer(routeMarkers_geojsonLayer);
                    routeMarkers_geojsonLayer = L.geoJson();
                }

                if(document.getElementById("rangeOfCar_Id").value != "" || document.getElementById("rangeOfCar_Id").value > 0) {
                    rangeOfCar = document.getElementById("rangeOfCar_Id").value * 1000;
                } else {
                    rangeOfCar = rangeOfCarDefault;
                }

                if(navigator.geolocation) {
                    var user_route = L.Routing.control({
                        waypoints: [
                            L.latLng(user_position.latitude, user_position.longitude),
                            destination
                        ],
                        routeWhileDragging: false
                    });

                    user_route.on('routesfound', function(e){
                        CalculateWhenToCharge(e.routes[0]);
                    });
                } else {
                    // Error message, "Can't find your location", Geolocation blocked, turned off or not supported by browser
                }
            }

            function SwitchLatLong(object) {
                return [object[1], object[0]];
            }

            function GetLocation(location){
                user_position.latitude = location.coords.latitude;
                user_position.longitude = location.coords.longitude;
                map.setView([user_position.latitude, user_position.longitude], 10); 
                userPosition_geojsonLayer = L.marker([user_position.latitude, user_position.longitude], {icon:userLocationIcon}).addTo(map);
                userPosition_geojsonLayer.bindPopup(userPosition_text);
            }

            function BuildLayers() {
                chargepole_geojsonLayer = L.geoJson(<?php echo $data ?>, {
                    pointToLayer:  function (feature, latLng) {
                        return new L.Marker(latLng, {
                          icon:chargepoleIcon
                        })
                    },
                    style: function (feature) {
                        return {color: feature.properties.color};
                    },
                    onEachFeature: function (feature, layer) {
                        layer.bindPopup(feature.properties.name + "<button id=\"selectpoint\" onclick=\"SelectPointChargepole('" + feature.properties.name + "')\">Route To Here</button>");
                        layer._leaflet_id = feature.properties.name;
                    }
                });

                tour_geojsonLayer = L.geoJson(<?php echo $pois ?>, {
                    pointToLayer:  function (feature, latLng) {
                        return new L.Marker(latLng, {
                          icon:POIIcon
                        })
                    },
                    style: function (feature) {
                        return {color: feature.properties.color};
                    },
                    onEachFeature: function (feature, layer) {
                        layer.bindPopup(feature.properties.name + "<button id=\"selectpoint\" onclick=\"SelectPointPOI('" + feature.properties.name + "')\">Route To Here</button>");
                        layer._leaflet_id = feature.properties.name;
                    }
                });

                routeMarkers_geojsonLayer = L.geoJson(null, {
                    style: function (feature) {
                        return {color: feature.properties.color};
                    },
                    onEachFeature: function (feature, layer) {
                        layer.bindPopup(feature.name); 
                    }
                });
            }

            function SelectPointChargepole(name) {
                SelectPoint(chargepole_geojsonLayer.getLayer(name));
            }

            function SelectPointPOI(name) {
                SelectPoint(tour_geojsonLayer.getLayer(name));
            }

            function SelectPoint(object) {
                destinationPopup
                    .setLatLng(object._latlng)
                    .setContent("Latitude: " + object._latlng.lat + "<br>Longitude: " + object._latlng.lng);
                destinationMarker
                    .setLatLng(object._latlng)
                    .bindPopup(destinationPopup)
                    .addTo(map);

                RouteToPoint(object._latlng);
            }

            function ShowAllChargepoles() {
                ClearMap();
                map.addLayer(chargepole_geojsonLayer);
            }

            function ShowAllPOI() {
                ClearMap();
                map.addLayer(tour_geojsonLayer);
            }

            function PaintCircleAtPoint(object) { 
               circles_geojsonLayer.addLayer(L.circle(L.latLng(object.latLng.lat, object.latLng.lng), walkingDistance));
               map.addLayer(circles_geojsonLayer);
            }

            function ClearMap() {
                /*if(map.hasLayer(selected_geojsonLayer)) {
                    removeLayer(selected_geojsonLayer);
                }*/
                /*if(map.hasLayer(circles_geojsonLayer)) {
                    map.removeLayer(circles_geojsonLayer);
                }*/
                if(map.hasLayer(chargepole_geojsonLayer)) {
                    map.removeLayer(chargepole_geojsonLayer);
                }
                if(map.hasLayer(tour_geojsonLayer)) {
                    map.removeLayer(tour_geojsonLayer);
                }
                if(map.hasLayer(tour_points_in_range_geojsonLayer)) {
                    map.removeLayer(tour_points_in_range_geojsonLayer);
                    map.addLayer(tour_points_in_range_geojsonLayer);
                }
            }

            function ResetMap() {
                if(navigator.geolocation) {
                    map.setView([user_position.latitude, user_position.longitude], 10);
                } else {
                    map.setView([56.505, 12.09], 6);
                }

                if(user_route != null) {
                    map.removeControl(user_route);
                    user_route = null;
                }

                if(calculated_route != null) {
                    map.removeControl(calculated_route);
                    calculated_route = null;
                }

                ClearMap();

                map.addLayer(userPosition_geojsonLayer);

                if(map.hasLayer(circles_geojsonLayer)) { 
                    map.removeLayer(circles_geojsonLayer);
                    circles_geojsonLayer = L.geoJson();
                }
                if(map.hasLayer(tour_points_in_range_geojsonLayer)) {
                    map.removeLayer(tour_points_in_range_geojsonLayer);
                    tour_points_in_range_geojsonLayer = L.geoJson();
                }
                if(map.hasLayer(routeMarkers_geojsonLayer)) {
                    map.removeLayer(routeMarkers_geojsonLayer);
                    routeMarkers_geojsonLayer = L.geoJson();
                }
            }

            /*
            * End of functions
            */
        </script>

    </body>
</html>
